/* Entfernt Whitespace am Ende und am Anfang von str.
 * Arbeitet in-place, d.h. liefert einen Substring
 * von str zurück. */
char* trim(char* str);

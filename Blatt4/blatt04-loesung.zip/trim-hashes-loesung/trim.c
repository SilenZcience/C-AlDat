#include <stdbool.h>

// intern für die Korrektur
#define CA_ID edoo4thaequei6EReu1eiw6Hei7it4oh

// geht davon aus, dass str null-terminated ist
char* trim(char* str) {
  // Stelle sicher, dass str mindestens ein Zeichen enthält
  // (sonst ist nichts zu tun)
  if(*str == '\0') {
    return str;
  }

  // suche linkestes Zeichen, das nicht '#' ist
  while(*str != '\0' && *str == '#') ++str;
  char* first_non_hash=str;

  // such rechtestes Zeichen, das nicht '#' ist; suche dazu
  // zunächst das Ende des Strings
  while(*str != '\0') ++str;
  // str steht jetzt auf '\0'; der Eingabestring enthält
  // mindestens ein Zeichen; daher können wir nach links
  // auf das letzte echte Zeichen des Strings laufen.
  --str;

  // Ende gefunden; jetzt suchen wir von rechts
  while(str != first_non_hash && *str == '#') --str;

  // Wir moechten gerne den String ein Zeichen nach
  // dem gefunden Zeichen terminieren.
  // Weil str nicht auf '\0' steht ist folgendes legal.
  *(str+1) = '\0';

  return first_non_hash;
}


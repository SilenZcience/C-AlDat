#include "hashtable.h"

#include <stdio.h>
#include <stdbool.h>

// intern für die Korrektur
#define CA_ID edoo4thaequei6EReu1eiw6Hei7it4oh

void init(HashTable* h, int a, int b, int p) {
    for(int i=0; i < TABLE_SIZE; ++i) {
        h->table[i].id = EMPTY;
    }

    h->n_collisions = 0;
    h->n_items = 0;
    h->a = a;
    h->b = b;
    h->p = p;
}

unsigned int hash(const HashTable* h, int key) {
    return (h->a*key + h->b) % h->p;
}

bool is_pos_empty(const HashTable* h, unsigned int pos) {
    return h->table[pos].id == EMPTY;
}

unsigned int insert(HashTable* h, Bird b) {
    unsigned int x = hash(h, b.id);
    for(int i=0; i < TABLE_SIZE; ++i) {
        const unsigned int probe_pos = (x+i) % TABLE_SIZE;
        if(is_pos_empty(h, probe_pos)){
            h->table[probe_pos] = b;
            ++h->n_items;
            return probe_pos;
        }
        ++h->n_collisions;
    }

    return TABLE_SIZE;
}

Bird get(const HashTable* h, int key) {
    unsigned int x = hash(h, key);
    for(int i=0; i < TABLE_SIZE; ++i) {
        const unsigned int probe_pos = (x+i) % TABLE_SIZE;
        if(h->table[probe_pos].id == key) {
            return h->table[probe_pos];
        }
    }

    Bird dummy = {-1, 0,0};
    return dummy;
}

void print_table(const HashTable* h) {
    printf("#");
    for(int i=0; i < TABLE_SIZE; ++i) {
        printf("  %03d#", i);
    }
    printf("\n");

    printf("#");
    for(int i=0; i < TABLE_SIZE; ++i) {
        if(is_pos_empty(h, i)){
            printf("%5s#", "");
        }
        else {
            printf("%5d#", h->table[i].id);
        }
    }
    printf("\n\n");
}

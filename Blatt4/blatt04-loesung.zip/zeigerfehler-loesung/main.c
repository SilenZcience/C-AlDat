#include <stdio.h>

// intern für die Korrektur
#define CA_ID quaePa6eehoh0jiiMeesoseiGh0yu3fo

typedef struct Foo {
    double v;
} Foo;

void init_foo(Foo* foo, double v) {
    foo->v = v; // Fehler 1: . statt ->
}

void cut_in_half(double* x) { // Fehler 2: x statt *x
    *x = *x / 2.0;
}

int main(void) {
    Foo f; // Fehler 3: Foo* statt Foo
    init_foo(&f, 1.0);

    printf("%.3f\n", f.v);

    Foo g;
    init_foo(&g, 2.0); // Fehler 4: g statt &g

    printf("%.3f\n", g.v);

    int a = 10;
    int* pa = &a; // Fehler 5: a statt &a

    printf("%d\n", *pa); // Fehler 6: pa statt *pa

    double x;
    cut_in_half(&x);
    printf("%.3f\n", x);

    const double e = 2.718;
    const double* pe = &e; // Fehler 7: const double e*
    printf("%.3f\n", *pe);

    int pi = 3;
    int* ppi = &pi; // Fehler 8: ohne const
    *ppi = 20;
    printf("%d\n", *ppi);

    char c = 'x';
    char* pc = &c;
    *pc = 'y'; // Fehler 9: *pc = 'y'
    printf("%c\n", *pc);

    return 0;
}






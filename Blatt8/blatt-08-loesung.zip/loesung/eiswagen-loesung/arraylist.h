#ifndef CA_ARRAYLIST_H_
#define CA_ARRAYLIST_H_

#include "eiswagen.h"
#include <stdio.h>

// TODO zur Speicherung von Kreuzungen anpassen
typedef struct ArrayList {
  Junction* arr;      // eigentliche Liste
  int size;      // #Elemente in Liste
  int capacity;  // Größe von arr
} ArrayList;

void al_init(ArrayList* l);

void al_destroy(ArrayList* l);

int al_append(ArrayList* l, int key);

void al_print(FILE* f, const ArrayList* l);

void al_print_with_streets(FILE* f, const ArrayList* l);


#endif

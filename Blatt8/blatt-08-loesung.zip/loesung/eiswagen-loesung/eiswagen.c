#include <stdbool.h>
#include "eiswagen.h"
#include "dlinkedlist.h"
#include "arraylist.h"

#define CA_ID ohrohy5iD5Aet0chie5sheiva2tohyoo

//Legt Kreuzung mit leerer Straßenliste an.
void junction_init(Junction *j, int ID){
    j->ID = ID;
    j->streets = malloc(sizeof(DList));
    // TODO Straßen initialisieren
    dlist_init(j->streets);
}

void junction_destroy(Junction *j) {
    dlist_destroy(j->streets);
    free(j->streets);
    j->streets = NULL;
}

// TODO: IDs in der Reihenfolge ihres Vorkommes in der Arraylist speichern.
// Wenn alle Kreuzungen eingelesen sind, soll die ArrayList einmal mit der
// Funktion al_print ausgegeben werden.
bool _read_junctions(FILE* f, ArrayList *junctions){
    int n_junctions = 0;
    if(fscanf(f, "%d\n", &n_junctions) != 1) { // Achtung: Hier muss man mit \n lesen, sonst funktioniert die andere Methode nicht!
        fprintf(stderr, "Fehler, konnte #Kreuzungen nicht lesen.\n");
        return false;
    }

    for(int i=0; i < n_junctions; ++i) {
        int j_id;
        fscanf(f, "%d\n", &j_id);
        al_append(junctions, j_id);
    }

    al_print(stdout, junctions);
    return true;
}


// TODO: Lese die Straßen ein, füge sie ein bzw. lösche sie und gebe die ArrayListe
// nach jeder Einfüge bzw. Löschvorgang mit al_print_with_streets aus.
bool _read_streets(FILE *f, ArrayList *junctions){
    int start;
    int stop;
    char mode;

    while(!feof(f)) {
        if(fscanf(f, "%c %d %d\n",&mode, &start, &stop) == 3) {
            // TODO: Finde die richtige verkettete Liste
            Junction* junc = junctions->arr;
            while(junc != &junctions->arr[junctions->size] && junc->ID != start) {
                ++junc;
            }

            if(mode == 'a'){
                dlist_insert(junc->streets, stop);
            } else if (mode == 'r'){
                // TODO entferne die Straße aus der entsprechenden Liste
                dlist_remove(junc->streets, stop);
            }
            else {
                fprintf(stderr, "Einlesefehler: Unbekannter Modus %c.\n", mode);
                return false;
            }
        } else {
            fprintf(stderr, "Fehler. Fehlerhafte Zeile.\n");
            return false;
        }
        // TODO Ausgabe mit al_print_with_streets
        al_print_with_streets(stdout, junctions);
    }
    return true;
}

int main(void){
    FILE* f = stdin;

    ArrayList *junctions = malloc(sizeof(ArrayList)); // Daniel: sizeof(ArrayList), nicht?
    al_init(junctions);
    if (!_read_junctions(f, junctions)){
        fprintf(stderr, "Fehler beim Einlesen der Kreuzungen.\n");
        return 1;
    }

    if (!_read_streets(f, junctions)){
        fprintf(stderr, "Fehler beim Einlesen der Straßen.\n");
        return 1;
    }

    for(int i=0; i < junctions->size; ++i) {
        junction_destroy(&junctions->arr[i]);
    }

    al_destroy(junctions);
    free(junctions);
    junctions=NULL;

    return 0;
}



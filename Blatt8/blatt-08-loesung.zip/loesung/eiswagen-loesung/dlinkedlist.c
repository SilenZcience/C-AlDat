#include "dlinkedlist.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

#define NIL -1

#define CA_ID_LIST eo2rah8ozeif1ohdaeHaijaizohngoh2

void delement_init(DListElement* e, int key) {
    e->key = key;
    e->_next = NULL;
    e->_prev = NULL;
}

DListElement* create_delement(int key) {
    DListElement* e = malloc(sizeof(DListElement));
    delement_init(e, key);
    return e;
}

void dlist_init(DList* l) {
    l->head = create_delement(NIL);
    l->tail = create_delement(NIL);
    l->head->_next = l->tail;
    l->tail->_prev = l->head;
    l->size = 0;
}

DList* create_dlist() {
    DList* l = malloc(sizeof(DList));
    dlist_init(l);
    return l;
}

void dlist_destroy(DList* l) {
    DListElement* cur = l->head;
    DListElement* next = cur->_next;
    while(cur != l->tail) {
        // solange cur != tail ist cur->next != null
        free(cur);

        cur = next;
        next = next->_next;
    }

    free(l->tail);
}

void dlist_print(const DList* l, FILE* f) {
    DListElement* cur = l->head->_next;
    fprintf(f, "HEAD -> ");
    while(cur != l->tail) {
        fprintf(f, "%d -> ", cur->key);
        cur = cur->_next;
    }
    fprintf(f, "TAIL\n");
}

// TODO: Soll ein neues Element sortiert (aufsteigend nach key) einfuegen. 
// Aendern Sie die Funktion (und ihre Signatur) entsprechend.
DListElement* dlist_insert(DList* l, int key) {
    DListElement* p = l->head;
    while(p->_next->key < key && p->_next != l->tail) p = p->_next;

    DListElement* e = create_delement(key);

    // Schritt 1
    e->_prev = p;
    e->_next = p->_next;

    // Schritt 2
    p->_next = e;
    e->_next->_prev = e;

    ++l->size;
    return e;
}

// TODO so Anpassen, dass nicht ein Element, sondern der key des zu entfernenden
// Elements übergeben wird.
void dlist_remove(DList* l, int key) {
    DListElement* e = l->head;
    while(e->key != key && e != l->tail) e = e->_next;

    if(e == l->tail) return;

    // Schritt 1 mit p=e.prev
    e->_prev->_next = e->_next;

    // Schritt 2 mit s=e.next
    e->_next->_prev = e->_prev;

    free(e);

    --l->size;
}

// TODO Binden Sie die erforderlichen Headerdateien ein
#include "hashmap.h"
#include "arraylist.h"
#include "mergesort.h"

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <string.h>
#include <stdbool.h>

#define MAX_WORD_LENGTH 255
#define RESULT_MSG "%s %d\n"

#define CA_ID EiTh4ohPhangeph6eisoi9tohyoot7ah

char* get_next_word(FILE* f) {
    char c;
    int n_word_chars=0;
    char word_buffer[MAX_WORD_LENGTH+1];

    while(fscanf(f, "%c", &c) == 1 && n_word_chars < MAX_WORD_LENGTH) {
        if(!isalpha(c)) break;
        word_buffer[n_word_chars++] = c;
    }
    if(n_word_chars == 0) return NULL;

    word_buffer[n_word_chars++] = '\0';

    char* next_word = malloc(sizeof(char)*n_word_chars);
    strncpy(next_word, word_buffer, n_word_chars);
    return next_word;
}

void normalize(char* str) {
    // TODO Wandeln Sie str in Kleinbuchstaben um
    //      Sie duerfen 'char tolower(char c)' aus <string.h> benutzen.
    while(*str != '\0'){
        *str = tolower(*str);
        ++str;
    }
}

int main(void) {
    // TODO Sie brauchen eine Hashtabelle
    //      Verwenden Sie hash_func als Hashfunktion.
    HashMap h;
    HashFunction hash_func = {4789, 1789, INT_MAX};
    hashmap_init(&h, hash_func);

    // TODO Sie brauchen eine Arrayliste
    ArrayList all_words;
    al_init(&all_words);

    FILE* infile = stdin;
    while(!feof(infile)) {
        char* next_word = get_next_word(infile);

        if(next_word == NULL) {
            continue;
        }

        // TODO Fuegen Sie next_word in die Hashtabelle
        normalize(next_word);

        HashElement* w = hashmap_get(&h, next_word);
        // w zum ersten Mal gesehen
        if(w == NULL) {
            // TODO Wann muessen Sie next_word in die Arrayliste einfuegen?
            al_append(&all_words, next_word);
            hashmap_insert(&h, next_word, 1);
        }
        else {
            w->value++;
            free(next_word);
        }
    }

    // TODO Sortieren Sie den Inhalt der Arrayliste
    merge_sort_bottom_up(all_words.arr, all_words.size);
    
    // TODO Gegeben Sie den Inhalt der Arrayliste aus
    for(int i=0; i < all_words.size; ++i) {
        char* word = al_get(&all_words, i);
        printf("%s %d\n", word, hashmap_get(&h, word)->value);
    }

    // TODO Geben Sie den Speicher wieder frei!
    hashmap_destroy(&h);

    for(int i=0; i < all_words.size; ++i) {
        free(al_get(&all_words, i));
    }
    al_destroy(&all_words);

    return 0;
}

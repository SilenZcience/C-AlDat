#ifndef CA_MERGESORT_H_
#define CA_MERGESORT_H_

void merge_sort_bottom_up(char** A, int n);

#endif

#ifndef CA_MERGESORT_H_
#define CA_MERGESORT_H_

#include "dlinkedlist.h"

void merge_sort_bottom_up(DList* L);

#endif

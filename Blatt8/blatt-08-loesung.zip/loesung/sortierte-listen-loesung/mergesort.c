#include "mergesort.h"

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#define CA_ID La9nu1waiyeiB1paesh2aengooXu6Oew

/* Merge L[l,...,m-1] mit L[m,...,r].
 *
 * Annahme: L[l,...,m-1] und L[m,...,r] sind aufsteigend sortiert
 */
void _merge(DList* L, DListElement* l, DListElement* m, DListElement* r) {
    // nur zur besseren Lesbarkeit, man könnte auch direkt l und m benutzen
    DListElement* l_pos = l; // Leseposition linker Teil
    DListElement* r_pos = m; // Leseposition rechter Teil

    // verschmelze bis eines der Teilarrays leer ist
    while(l_pos != r_pos && r_pos != r) {
        if(l_pos->key < r_pos->key){
            l_pos = l_pos->_next;
        }
        else {
            DListElement* next = r_pos->_next;
            dlist_move(L, r_pos, l_pos->_prev);
            r_pos = next;
        }
    }
}

/* Bottom-up MergeSort: Mache log n Passes über L, in Pass i, merge alle Teillisten
 * der Größe 2^i */
void merge_sort_bottom_up(DList* L) {
    for(int chunk_size=1; chunk_size < L->size; chunk_size *= 2) { // Teil-Liste in Pass i
        printf("-- Pass %d\n", chunk_size);
        dlist_print(L, stdout);
        DListElement* l = L->head->_next;
        while(l != L->tail) {
            DListElement* m = l;
            for(int i=0; i < chunk_size - 1 && m != L->tail; ++i) m=m->_next;

            // kein erster / zweiter Chunk vorhanden
            if(m == L->tail || m->_next == L->tail) break;

            DListElement* r = m;
            for(int i=0; i < chunk_size && r->_next != L->tail; ++i) r = r->_next;

            DListElement* next_l = r->_next;

            _merge(L, l, m->_next, r->_next);
            l=next_l;
        }
        dlist_print(L, stdout);
    }
}

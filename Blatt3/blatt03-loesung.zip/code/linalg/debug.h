#ifdef CA_DEBUG
#define ca_dbg(x) x
#else
#define ca_dbg(x)
#endif

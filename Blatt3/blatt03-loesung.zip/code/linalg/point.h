#ifndef CALDAT_POINT_H
#define CALDAT_POINT_H

struct Point3d {
    double x;
    double y;
    double z;
};

typedef struct Point3d Point3d;

#endif

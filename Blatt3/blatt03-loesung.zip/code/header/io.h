#ifndef CALDAT_IO_H_
#define CALDAT_IO_H_

#define CA_ID oi9iehox3yee5ahy6reejai3Ia7Oe1ee

#include "fraction.h"

void print_fraction(Fraction x);

#endif

#include "io.h"

#include <stdio.h>

void print_fraction(Fraction x) {
    printf("%d/%d", x.p, x.q);
}

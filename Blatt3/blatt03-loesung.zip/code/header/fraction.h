#ifndef CALDAT_FRACTION_H_
#define CALDAT_FRACTION_H_

#define CA_ID oi9iehox3yee5ahy6reejai3Ia7Oe1ee

#include <stdbool.h>

typedef struct Fraction {
    int p;
    int q;
} Fraction;

Fraction make_fraction(int p, int q);

Fraction scalar_mult(int factor, Fraction x);

Fraction simplify(Fraction x);

Fraction mult(Fraction x, Fraction y);

Fraction add(Fraction x, Fraction y);

bool equal(Fraction x, Fraction y);

bool greater_equal(Fraction x, Fraction y);

bool less_equal(Fraction x, Fraction y);

bool less(Fraction x, Fraction y);

bool greater(Fraction x, Fraction y);

#endif


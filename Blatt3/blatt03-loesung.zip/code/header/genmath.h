#define CA_ID oi9iehox3yee5ahy6reejai3Ia7Oe1ee

int iabs(int a);

/* berechnet den groessten gemeinsamen Teiler von a,b >= 0 */
int gcd(int a, int b);

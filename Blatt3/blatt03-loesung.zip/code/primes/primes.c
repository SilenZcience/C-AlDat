#include "primes.h"

#include <stdio.h>
#include <stdbool.h>
#include <assert.h>

// intern für die Korrektur
#define CA_ID Nooveus3ZouKeoM5uajoKiag3Oovaeph

void print_primes(int n) {
    // implementiert das Sieb des Erastosthenes in O(n*sqrt(n))

    // Sieb: Initial sind alle Zahlen >= 2 potentiell Primzahlen
    //       Der Algorithmus kreuzt alle Zahlen aus, die nicht prim
    //       sein können.
    bool is_prime[n+1];
    is_prime[0] = false; // 0 und 1 sind per Def. keine Primzahlen
    is_prime[1] = false;
    for(int i=2; i <= n; ++i) is_prime[i] = true;

    // Für i: Kreuze alle Vielfachen von i (außer i selbst) aus.
    //
    // Beobachtungen für zwei Laufzeitverbesserungen:
    // 1. Wenn k = a*b nicht prim ist, o.B.d.A. a < b, ist k ein
    //    Vielfaches von a und von b. Es genügt, k im Durchlauf
    //    von a auszukreuzen. Da $k <= n$ können wir also die
    //    Durchläufe mit a > sqrt(n) (<=> a*a > n) einsparen.
    //
    // 2. Ist is_prime[i] = false dann wurden die Vielfachen von i
    //    bereits in einer vorherigen Iteration ausgekreuzt.
    for(int i=1; i*i <= n; ++i){
        // Invariante: In is_prime[1,...,i-1] sind genau die Einträge
        //             der Primzahlen zwischen 1,...,i-1 auf true gesetzt.
        if(!is_prime[i]) continue;

        for(int j=2*i; j <=n; j += i) {
            is_prime[j] = false;
        }
    }

    // Jetzt sind genau alle Primzahlen mit true markiert.
    for(int i=1; i <= n; ++i) {
        if(is_prime[i]) {
            assert(is_prime_number(i));
            printf("%d\n", i);
        }
        else {
            assert(!is_prime_number(i));
        }
    }
}

/* Testet in Zeit O(k) ob k >= 1 eine Primzahl ist. */
bool is_prime_number(int k) {
    assert(k >= 1);

    // 1 ist per Definition keine Primzahl
    if(k==1) return false;

    // Teste, ob eine Zahl i < k die Zahl k ohne Rest teilt.
    for(int i=2; i < k; ++i){
        if(k % i == 0) {
            return false;
        }
    }

    return true;
}


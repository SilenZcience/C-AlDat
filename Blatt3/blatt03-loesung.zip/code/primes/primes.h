#ifndef CALDAT_PRIMES_H_
#define CALDAT_PRIMES_H_

void print_primes(int n);

#endif

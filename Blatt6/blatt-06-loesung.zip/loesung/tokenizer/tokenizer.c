#include "tokenizer.h"

#include <stdio.h>
#include <stdlib.h>

#define CA_ID_TKC eethieTael0OoChae1aeThoicohqu8hi

/* Liefert den Teilstring str[l,...,r] als Kopie in einem neuen Array der
 * Länge r-l+1 zurück.
 *
 * Der Aufrufer ist dafür verantwortlich, die Kopie zu löschen.
 */
char* substring(char* str, int l, int r) {
  const int n = r-l+1;
  char* substr = (char*) malloc(sizeof(char) * (n+1));
  for(int i=0; i < n; ++i) {
    substr[i] = str[l+i];
  }
  substr[n] = '\0';
  return substr;
}

/* Zerteilt einen String an jedem Vorkommen des Separators sep in Teilstrings,
 * die wir Tokens nennen. Liefert die Tokens/Teilstrings in einem Array und
 * die Länge dieses Arrays in *n_tokens zurück.
 *
 * Ein Separator am Anfang oder Ende des Eingabestrings führt dazu, dass das
 * erste bzw. letzte Token der leere String ist. Wenn der Eingabestring
 * n Vorkommen von sep enthält, ist *n_tokens daher genau n+1.
 *
 * Die zurückgelieferten Tokens sind Kopien des ursprünglichen Strings.
 *
 * Der Aufrufer ist dafür verantwortlich, das zurückgelieferte Array und alle
 * Teilstrings zu löschen.
 */
char** tokenize(char* str, char sep, int* n_tokens) {
  *n_tokens = 1;
  char* seeker=str;
  while(*seeker != '\0'){
    if(*seeker == sep) ++(*n_tokens);
    ++seeker;
  }

  char** tokens = (char**) calloc(sizeof(char*), *n_tokens);
  int l = 0;
  int r = l;
  for(int i=0; i < *n_tokens; ++i) {
    while(str[r] != '\0' && str[r] != sep) ++r;
    tokens[i] = substring(str, l,r-1); // separator / '\0' soll nicht kopiert werden

    l=r+1;
    r=l;
  }

  return tokens;
}

/* Löscht alle in tokens enthaltenen Teilstrings und das Array tokens selbst */
void free_tokens(char** tokens, int n) {
  for(int i=0; i < n; ++i) {
    free(tokens[i]);
    tokens[i] = NULL;
  }
  free(tokens);
}


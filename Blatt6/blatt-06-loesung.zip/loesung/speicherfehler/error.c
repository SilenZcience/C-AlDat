#include <stdio.h>
#include <stdlib.h>

#define CA_ID raaneeY4ailaeloh0uZoh8aiv6iekeng

typedef struct Foo{
    double* arr;
    int size;
} Foo;

int imin(int x, int y){
    return (x <= y ? x : y);
}

double* init_array(int n) {
    double* array = (double*) malloc(n*sizeof(double)); // zu Fehler 1
    for(int i=0; i < n; ++i) {
        array[i] = i;
    }
    return array; // Fehler 1: lokales Array zurückgegeben, malloc in Zeile 14
}

Foo* create_foo(int size) {
    Foo* f = (Foo*) malloc(sizeof(Foo));   // Fehler 2: kein Speicherplatz für Foo reserviert... malloc
    f->arr = init_array(size);
    f->size = size;
    return f;
}

// wir schreiben einen Destruktor für Foo zur Vereinfachung
void destroy_foo(Foo* f) {
    free(f->arr);
    free(f);
}

void print_foo(const Foo* f) {
    for(int i=0; i < f->size; ++i) {
        printf("%.3f", f->arr[i]);
    }
    printf("\n");
}

Foo* add_foo(Foo f1, Foo f2) {
    int n = imin(f1.size, f2.size);

    Foo* sum = (Foo*) malloc(sizeof(Foo)); // Fehler 3: sizeof(Foo) wäre richtig
    sum->arr = (double*) malloc(n*sizeof(double)); // zu Fehler 4
    sum->size = n; // für diese drei Zeilen hätte man auch create_foo benutzen können

    for(int i=0; i < n; ++i) {
        sum->arr[i] = f1.arr[i] + f2.arr[i]; // Fehler 4: sum->arr ist nicht allokiert
    }

    return sum;
}

int main(void) {
    const int n_foos = 10;
    const int foo_size = 5;
    Foo** foos = (Foo**) malloc(n_foos*sizeof(Foo*));
    for(int i=0; i < n_foos; ++i) {
        foos[i] = create_foo(foo_size);
    }

    for(int i=0; i < n_foos; ++i) {
        print_foo(foos[i]);
    }

    Foo* foo_sum = add_foo(*foos[0], *foos[1]);
    print_foo(foo_sum);

    // Fehler 5: foo_sum muss gelöscht werden, und foo_sum->arr
    destroy_foo(foo_sum);

    // Fehler 6: In jedem Foo f muss f->arr gelöscht werden
    // Fehler 7: jeder Eintrag von foos muss gelöscht werden
    // hier sieht man, warum ein Destruktor nütlich ist!
    for(int i=0; i < n_foos; ++i) {
        destroy_foo(foos[i]);
    }

    // Fehler 8: foos muss gelöscht werden
    free(foos);

    return 0;
}


#include <stdio.h>
#include <stdlib.h>

#define CA_ID raaneeY4ailaeloh0uZoh8aiv6iekeng

typedef struct Foo{
    double* arr;
    int size;
} Foo;

int imin(int x, int y){
    return (x <= y ? x : y);
}

double* init_array(int n) {
    double array[n]; // zu Fehler 1
    for(int i=0; i < n; ++i) {
        array[i] = i;
    }
    return array; // Fehler 1: lokales Array zurückgegeben, malloc in Zeile 14 (2 Punkte)
}

Foo* create_foo(int size) {
    Foo* f;   // Fehler 2: kein Speicherplatz für Foo reserviert... malloc
    f->arr = init_array(size);
    f->size = size;
    return f;
}

void print_foo(const Foo* f) {
    for(int i=0; i < f->size; ++i) {
        printf("%.3f", f->arr[i]);
    }
    printf("\n");
}

Foo* add_foo(Foo f1, Foo f2) {
    int n = imin(f1.size, f2.size);
    Foo* sum = (Foo*) malloc(sizeof(Foo*)); // Fehler 3: sizeof(Foo) wäre richtig

    for(int i=0; i < n; ++i) {
        sum->arr[i] = f1.arr[i] + f2.arr[i]; // Fehler 4: sum->arr nicht allok.
    }

    return sum;
}

int main(void) {
    const int n_foos = 10;
    const int foo_size = 5;
    Foo** foos = (Foo**) malloc(n_foos*sizeof(Foo*));
    for(int i=0; i < n_foos; ++i) {
        foos[i] = create_foo(foo_size);
    }

    for(int i=0; i < n_foos; ++i) {
        print_foo(foos[i]);
    }

    Foo* foo_sum = add_foo(*foos[0], *foos[1]);
    print_foo(foo_sum);

    // Fehler 5: foo_sum muss gelöscht werden
    // Fehler 6: In jedem Foo f muss f->arr gelöscht werden
    // Fehler 7: jeder Eintrag von foos muss gelöscht werden (2 Punkte)
    // Fehler 8: foos muss gelöscht werden

    return 0;
}


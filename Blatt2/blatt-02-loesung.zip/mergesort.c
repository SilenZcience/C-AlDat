/* C-Programmierung für Algorithmen und Datenstrukturen
 *
 * Musterlösung Blatt 2, Aufgabe MergeSort
 *
 * Compilieren mit gcc -Wall -o mergesort mergesort.c
 * Aufruf: ./mergesort < eingabe.txt
 */

#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <stdlib.h>
#include <math.h>
#include <tgmath.h>

#ifndef NDEBUGOUT
#define debug(x) x
#else
#define debug(x)
#endif

// intern für die Bewertung
#define AD_ID elae2dimohkeef3phahfaiBeeh2aighu

/* Gibt Elemente aus Array A[l...r] auf Standardeingabe (Konsole) aus */
void print_subarray(int A[], int l, int r) {
    for(int i=0; i < l; ++i) {
        printf(" %3s ", "");
    }

    for(int i=l; i <= r; ++i){
        printf(" %3d ", A[i]);
    }
    printf("\n");
}

/* Gibt n Elemente aus Array A auf Standardeingabe (Konsole) aus */
void print_array(int A[], int n){
    print_subarray(A, 0, n-1);
}

/* Testet, ob A[l...r] aufsteigend sortiert ist. */
bool is_sorted(int A[], int l, int r) {
    for(int i=l; i < r; ++i) { // Fehler 1: <= statt <
        if(A[i] > A[i+1]) {
            return false; // Fehler 2: true/false vertauscht
        }
    }

    return true;
}


/* Liest n ganze Zahlen in ein Array mit mindestens n Plätzen. 
 *
 * Rückgabe: 0 falls erfolgreich, Fehlercode > 0 sonst.
 *
 * Erwartetes Eingabeformat:
 *
 * <Anzahl Schlüssel>
 * <Schlüssel 1>
 * ...
 * <Schlüssel n>
 */
int read_array(int A[], int n) {
    int n_read=0;
    while(n_read < n) {
        int num;

        if(scanf("%d", &num) < 1){ 
            // teste, ob Dateiende erreicht
            if(feof(stdin)) {
                printf("Falsches Eingabeformat. ");
                printf("%d Schlüssel erwartet, aber nur %d Schlüssel gefunden.\n", n, n_read);
                return 2;
            }
         
            // teste, ob sonstiger Fehler
            if(ferror(stdin)){
                printf("Ein-/Ausgabefehler.\n");
                return 3;
            }
         
            // ansonsten: Zeile konnte nicht geparst werden
            printf("Falsches Eingabeformat. ");
            printf("Zeile %d: Ganze Zahl erwartet.\n", n_read+2);
            return 4;
        }

        // erfolgreich gelesen
        A[n_read++] = num; // Fehler 3: hier fehlt ein ++
    }

    return 0;
}

/* Merge A[l,...,m] mit A[m+1,...,r]. 
 * Benutzt Hilfsarray H, H[l,...,r] wird überschrieben.
 *
 * Annahme: A[l,...,m] und A[m+1,...,r] sind aufsteigend sortiert */
void merge(int A[], int l, int m, int r, int H[]) {
    assert(is_sorted(A, l, m));   // Hier sollte man per Assertion prüfen,
    assert(is_sorted(A, m+1, r)); // ob Teilarrays sortiert sind


    // kopiere A in Hilfsarray
    for(int i=l; i <= r; ++i) { 
        H[i] = A[i];
    }

    int out_pos = l; // Schreibposition in A
    int l_pos = l;   // Leseposition linker Teil
    int r_pos = m+1; // Leseposition rechter Teil

    // verschmelze bis eines der Teilarrays leer ist
    while(l_pos <= m && r_pos <= r) {
        if(H[l_pos] < H[r_pos]){
            A[out_pos++] = H[l_pos++];
        }
        else {
            A[out_pos++] = H[r_pos++]; // Fehler 4: l_pos statt r_pos
        }
    }

    // Fehler 5: Hier fehlt ein Stück Code:
    // kopiere restlichen Elemente falls rechter Teil leer
    while(l_pos <= m) {
        A[out_pos++] = H[l_pos++];
    }

    assert(is_sorted(A, l, r)); // Auch Ergebnis kann man per Assertion gut prüfen
}

/* ruft MergeSort auf Teilarray A[l...r] auf */
void merge_sort_(int A[], int l, int r, int H[]) {
    if(l < r) {
        const int m = (l+r) / 2;
        merge_sort_(A, l, m, H);
        merge_sort_(A, m+1, r, H);
        merge(A, l, m, r, H);
        debug(print_subarray(A, l, r));
    }
}

/* ruft MergeSort auf Array a mit n Elementen auf */
void merge_sort(int A[], int n) {
    int H[n]; // Hilfsarray  
    merge_sort_(A, 0, n-1, H); // Fehler 6: Aufruf mit n statt n-1
}

int main(void) {
    int n;
    if(scanf("%d", &n) < 1) {
        printf("Falsches Eingabeformat. ");
        printf("Zeile 1: Ganze Zahl (Anzahl Schlüssel) erwartet.\n");
        return 1;
    }

    int A[n]; // Eingabearray
    int error = read_array(A, n);
    if(error > 0) {
        return error;
    }
    merge_sort(A, n);

    debug(print_array(A, n));
    assert(is_sorted(A, 0, n-1));

    return 0;
}

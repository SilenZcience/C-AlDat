/* C-Programmierung für Algorithmen und Datenstrukturen
 *
 * Musterlösung Blatt 2, Aufgabe Checks and Balances
 *
 * Compilieren mit gcc -Wall -o balances balances.c
 * Aufruf: ./balances < eingabe.txt
 */


#include <stdio.h>

// intern für die Bewertung
#define AD_ID EzaeQuae0nei5oxeiviebahsee8Ahphe

typedef struct Transaction {
    unsigned int id;
    int balance;
} Transaction;

/* Angepasste MergeSort Implementierung für Transaction
 *
 * Merge A[l,...,m] mit A[m+1,...,r].
 * Benutzt Hilfsarray H, H[l,...,r] wird überschrieben.
 *
 * Annahme: A[l,...,m] und A[m+1,...,r] sind aufsteigend sortiert */
void merge(Transaction A[], int l, int m, int r, Transaction H[]) {
    // kopiere A in Hilfsarray
    for(int i=l; i <= r; ++i) {
        H[i] = A[i];
    }

    int out_pos = l; // Schreibposition in A
    int l_pos = l;   // Leseposition linker Teil
    int r_pos = m+1; // Leseposition rechter Teil

    // verschmelze bis eines der Teilarrays leer ist
    while(l_pos <= m && r_pos <= r) {
        if(H[l_pos].id < H[r_pos].id){ // Modifikation für Transaction statt int!
            A[out_pos++] = H[l_pos++];
        }
        else {
            A[out_pos++] = H[r_pos++];
        }
    }

    // kopiere restlichen Elemente falls rechter Teil leer
    while(l_pos <= m) {
        A[out_pos++] = H[l_pos++];
    }
}

/* ruft MergeSort auf Teilarray A[l...r] auf */
void merge_sort_(Transaction A[], int l, int r, Transaction H[]) {
    if(l < r) {
        const int m = (l+r) / 2;
        merge_sort_(A, l, m, H);
        merge_sort_(A, m+1, r, H);
        merge(A, l, m, r, H);
    }
}

/* ruft MergeSort auf Array a mit n Elementen auf */
void merge_sort(Transaction A[], int n) {
    Transaction H[n]; // Hilfsarray
    merge_sort_(A, 0, n-1, H);
}

/* Liest n Transaktionen von stdin / analog zu read_array
 *
 * Rückgabe: 0 falls erfolgreich, Fehlercode > 0 sonst.
 *
 * Erwartetes Eingabeformat:
 *
 * <Anzahl Transaktionen>
 * <id 1> <balance 1>
 * ...
 * <id n> <balance n>
 */
int read_transactions(Transaction A[], int n) {
    int n_read=0;
    while(n_read < n) {
        if(scanf("%d %d", &A[n_read].id, &A[n_read].balance) != 2){
            // teste, ob Dateiende erreicht
            if(feof(stdin)) {
                printf("Falsches Eingabeformat. ");
                printf("%d Schlüssel erwartet, aber nur %d Schlüssel gefunden.\n", n, n_read);
                return 2;
            }

            // teste, ob sonstiger Fehler
            if(ferror(stdin)){
                printf("Ein-/Ausgabefehler.\n");
                return 3;
            }

            // ansonsten: Zeile konnte nicht geparst werden
            printf("Falsches Eingabeformat. ");
            printf("Zeile %d: Zwei ganze Zahlen erwartet.\n", n_read+2);
            return 4;
        }

        ++n_read;
    }

    return 0;
}

int main(void) {
    int n_orders;
    int n_payments;
    if(scanf("%d %d", &n_orders, &n_payments) != 2) {
        printf("Falsches Eingabeformat. ");
        printf("Zeile 1: Zwei ganze Zahlen erwartet.\n");
        return 1;
    }

    Transaction orders[n_orders]; // Bestellungen
    int error = read_transactions(orders, n_orders);
    if(error > 0) {
        return error;
    }

    Transaction payments[n_payments]; // Zahlungen
    error = read_transactions(payments, n_payments);
    if(error > 0) {
        return error;
    }

    // Trick: sortiere Bestellungen und Zahlungen nach ID!
    merge_sort(orders, n_orders);
    merge_sort(payments, n_payments);

    int i_orders = 0;
    int i_payments = 0;

    // Da Bestellungen/Zahlungen sortiert sind, können wir parallel
    // durch die Arrays laufen und vergleichen.
    int unpaid_total= 0;
    while(i_orders < n_orders && i_payments < n_payments) {
        if(orders[i_orders].id < payments[i_payments].id) {
            // naechste Zahlung hat groessere ID als naechste Bestellung; also
            // Bestellung nicht bezahlt.
            printf("%d\n", orders[i_orders].id);
            unpaid_total += orders[i_orders].balance;
            ++i_orders;
        }
        else if(orders[i_orders].id > payments[i_payments].id) {
            // naechste Zahlung hat groessere ID als naechste Bestellung;
            // also wurde etwas bezahlt, was nicht bestellt wurde.
            // Sollte nicht passieren ;)
            ++i_payments;
        }
        else {
            // Naechste Bestellung und naechstes Zahlung haben die gleiche ID,
            // also wurde die Bestellung bezahlt.
            ++i_orders;
            ++i_payments;
        }
    }
    // Wenn die Schleife terminiert, weil alle Zahlungen durchlaufen wurden
    // sind evtl. noch unbezahlte Bestellungen übrig
    while(i_orders < n_orders) {
        printf("%d\n", orders[i_orders].id);
        unpaid_total += orders[i_orders].balance;
        ++i_orders;
    }

    printf("%d\n", unpaid_total);

    /* Alternative Lösung 1: Binäre Suche in O(m \log m + n)
     *
     * 1) Sortiere Zahlungen mit MergeSort
     * 2) Für jede Bestellung:
     * 3)     Suche Rechnungsnummer der Bestellung in Zahlungen
     *        mit binärer Suche.
     */

    /* Alternative Lösung 2: Paarweise Vergleiche in O(n*m)
     *
     * 1) Für jede Rechnung:
     * 2)     Suche Rechnungsnummer in Zahlungen
     * 3) Sortiere Rechnungsnummern für Ausgabe (für Testfälle nötig)
     */

    /* Alternative Lösung 3 in Zeit O( (m+n) log (m+n)): Alles in ein Array
     *
     * 1) Schreibe Bestellungen und Zahlungen in ein Array
     * 2) Sortiere das Array mit MergeSort; Zahlung steht jetzt immer neben Rechnung
     * 3) Vergleiche jeweils Element i mit Element i+1
     */

    return 0;
}



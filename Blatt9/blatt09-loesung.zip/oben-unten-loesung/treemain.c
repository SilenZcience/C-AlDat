#include "bintree.h"
#include "dlinkedlist.h"

#include <stdio.h>
#include <stdlib.h>

#define CA_ID shiuvijae4gaephei4ooK1mi2ji9faiB

BinTree* read_tree(FILE* f);

void print_levels(const BinTree* t, FILE* f) {
    if(!t->root) return;

    DList* l = create_dlist();
    dlist_push_back(l, t->root);
    while(l->size > 0) {
        BinTreeNode* v = dlist_pop_front(l);
        printf("%d\n", v->key);
        if(v->left) dlist_push_back(l, v->left);
        if(v->right) dlist_push_back(l, v->right);
    }

    dlist_destroy(l);
    free(l);
}

int main(void) {
    BinTree* t = read_tree(stdin);
    if(!t) {
        fprintf(stderr, "Fehler beim Lesen der Eingabe.\n");
        return 1;
    }

    print_levels(t, stdout);

    FILE* dotfile = fopen("tree.dot", "w");
    bt_print_as_dot(t, dotfile);
    fclose(dotfile);

    bt_destroy(t);
    free(t);

    return 0;
}

BinTree* read_tree(FILE* f) {
    BinTree* t = create_bintree();

    while(!feof(f)) {
        int key;

        if(fscanf(f, "%d\n", &key) != 1) {
            fprintf(stderr, "Fehlerhafte Zeile.\n");
            bt_destroy(t);
            free(t);
            return NULL;
        }

        bt_add(t, key);
    }



    return t;
}

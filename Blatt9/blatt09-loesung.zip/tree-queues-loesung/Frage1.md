## Frage 1 (Zum Bearbeiten auf Github oben rechts auf den Bleistift klicken)

Welche asymptotische Worst-Case-Laufzeit besitzt die Methode **minimum** der
hier gegebenen Implementierung eines binären Suchbaumes?

Es sei n die Anzahl der Schlüssel im Suchbaum.

- [ ] O(log n)
- [x] O(n)
- [ ] O(n log n)
- [ ] O(n^2)

### Anleitung
Bitte so ankreuzen:

- [ ] nicht angekreuzt
- [x] angekreuzt.

Bitte ausser dem Kreuz nichts in der Datei verändern!

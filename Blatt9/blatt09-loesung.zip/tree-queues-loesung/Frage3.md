## Frage 3 (Zum Bearbeiten auf Github oben rechts auf den Bleistift klicken)

Welche asymptotische Worst-Case-Laufzeit besitzt die Methode **update_key**
der Prioritätswarteschlange, wenn die Warteschlange wie hier als
binärer Suchbaum implementiert ist?

Es sei n die Anzahl der Schlüssel in der Prioritätswarteschlange.

- [ ] O(log n)
- [x] O(n)
- [ ] O(n log n)
- [ ] O(n^2)

### Anleitung
Bitte so ankreuzen:

- [ ] nicht angekreuzt
- [x] angekreuzt.

Bitte ausser dem Kreuz nichts in der Datei verändern!

#ifndef CA_TREE_QUEUE
#define CA_TREE_QUEUE

#include "bintree.h"

typedef struct PrioQueue PrioQueue;

struct PrioQueue {
    BinTree* t;
};

// Gibt den zugrundeliegenden Baum in Pre-Order aus
void pq_print(const PrioQueue* q, FILE* f);

// TODO implementieren Sie alle folgenden Methoden in prioqueue.c

void pq_init(PrioQueue* q);
void pq_destroy(PrioQueue* q);
PrioQueue* create_pq();

int pq_extract_min(PrioQueue* q);
int pq_extract_max(PrioQueue* q);

void pq_insert(PrioQueue* q, int key);
void pq_update_key(PrioQueue* q, int key, int new_key);

size_t pq_size(const PrioQueue *q);

#endif

#include <stdio.h>

#define CA_ID oolekiequo7ewuNaD2pi2ohmohchu8ey

const char* outfile_name = "numbers.out";

void print_error(int row, int col) {
    fprintf(stderr, "Fehler: Konnte Zeile %d nicht lesen: Fehler in Spalte %d.\n", row, col);
}

void init_array(int arr[], int n, int val) {
    for(int i=0; i < n; ++i) {
        arr[i] = val;
    }
}

void print_array(FILE* out, int arr[], int n) {
    for(int i=0; i < n; ++i) {
        fprintf(out, "%d ", arr[i]);
    }
    fprintf(out, "\n");
}

int read_table(FILE* infile, int n_cols, int n_rows, int col_sums[]) {
    for(int i=0; i < n_rows; ++i) {
        for(int j=0; j < n_cols; ++j) {
            int num;
            if(fscanf(infile, "%d", &num) != 1) {
                print_error(i+2, j+1);
                return 0;
            }
            col_sums[j] += num;
        }

        print_array(stdout, col_sums, n_cols);
    }

    return 1;
}

int main(int argn, const char* args[]) {
    if(argn < 2) {
        fprintf(stderr, "Aufruf mit ./sum <Eingabedatei>\n");
        return 1;
    }

    FILE* infile = fopen(args[1], "r");
    if(infile == NULL) {
        fprintf(stderr, "Konnte Eingabedatei '%s' nicht öffnen.\n", args[1]);
        return 2;
    }

    int n_cols;
    int n_rows;
    if(fscanf(infile, "%d %d", &n_rows, &n_cols) != 2) {
        fprintf(stderr, "Fehler: Konnte Zeile 1 (#Zeilen #Spalten) nicht lesen\n");
        fclose(infile);
        return 3;
    }

    int col_sums[n_cols];
    init_array(col_sums, n_cols, 0);
    if(!read_table(infile, n_cols, n_rows, col_sums)){
        fclose(infile);
        return 4;
    }
    fclose(infile);

    FILE* outfile = fopen(outfile_name, "w");
    if(outfile == NULL){
        fprintf(stderr, "Fehler: Konnte Ausgabedatei '%s' nicht öffnen\n", outfile_name);
        return 5;
    }
    print_array(outfile, col_sums, n_cols);
    fclose(outfile);

    return 0;
}

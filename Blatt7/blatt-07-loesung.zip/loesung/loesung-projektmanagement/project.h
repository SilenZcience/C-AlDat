#ifndef CA_PROJECT_H_
#define CA_PROJECT_H_

struct Project {
    int id;
    int value;
};

typedef struct Project Project;

#endif

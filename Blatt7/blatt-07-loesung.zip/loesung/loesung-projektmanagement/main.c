#include "binheap.h"
#include "project.h"

#include <stdio.h>
#include <stdlib.h>

#define CA_ID Ua8dai7feth1ooraoSoofa0ohngiePhi

#define MSG_PROJECT_QUEUED_AT_TEAM "Projekt %d wird bei Team %d eingereiht.\n"
#define MSG_TEAM_START "Team %d beginnt %d.\n"
#define MSG_TEAM_DONE "Team %d beendet %d.\n"

enum Team { plan, dev, qual, n_teams };
typedef enum Team Team;

int main(void) {
    FILE* f = stdin;

    // TODO Sie brauchen einen Heap für jedes Team. Speichern Sie auch das aktuelle Projekt fuer jedes Team.
    BinHeap queue[n_teams];
    Project* cur_project[n_teams];
    for(Team t=plan; t < n_teams; ++t) {
        heap_init(&queue[t]);
        cur_project[t] = NULL;
    }

    while(!feof(f)) {
        // naechster Zeitschritt: alle freien Teams bekommen ein Projekt
        // TODO Weisen Sie hier allen Teams ein neues Projekt zu, die gerade
        // nicht beschaeftigt sind.
        for(Team t=plan; t < n_teams; ++t) {
            if(!cur_project[t] && queue[t].size > 0) {
                cur_project[t] = heap_extract_max(&queue[t]);
                printf(MSG_TEAM_START, t, cur_project[t]->id);
            }
        }

        int id;
        int value;

        int team_id;

        if(fscanf(f, "p %d %d\n", &id, &value) == 2) {
            // TODO Ein Projekt mit ID id und Wert value beginnt 
            //      und muss dem Planungsteam zugewiesen werden.
            Project* new_proj = malloc(sizeof(Project));

            new_proj->id = id;
            new_proj->value = value;

            printf(MSG_PROJECT_QUEUED_AT_TEAM, new_proj->id, 0);
            heap_insert(&queue[plan], new_proj);
            continue;
        }

        if(fscanf(f, "f %d\n", &team_id) == 1){
            // TODO Das Team team_id hat das aktuelle Projekt
            //      beendet. Es muss dem nächsten Team zugewiesen
            //      werden oder ist vollständig abgeschlossen.
            if(cur_project[team_id] == NULL) {
                printf("Fehler: Kein aktuelles Projekt zum Beenden vorhanden!.\n");
                continue;
            }

            // Projekt abgeschlossen; reiche es an naechstes Team weiter
            printf(MSG_TEAM_DONE, team_id, cur_project[team_id]->id);
            Project* finished_project = cur_project[team_id];
            cur_project[team_id] = NULL;

            // Gibt es ein naechstes Team?
            if(team_id +1 == n_teams) {
                // Nein, Projekt vollstaendig beendet.
                free(finished_project);
                continue;
            }

            // Projekt wird beim naechsten Team eingereiht
            printf(MSG_PROJECT_QUEUED_AT_TEAM, finished_project->id, team_id+1);
            heap_insert(&queue[team_id+1], finished_project);
        }
    }

    // Gebe verbleibende Projekte in den Heaps frei
    for(int t=plan; t < n_teams; ++t) {
        while(queue[t].size > 0) {
            free(heap_extract_max(&queue[t]));
        }
        heap_destroy(&queue[t]);
        free(cur_project[t]);
    }

    return 0;
}

#ifndef CA_BINHEAP_ARRAY_H_
#define CA_BINHEAP_ARRAY_H_

#include "project.h"
#include <stdbool.h>

void heapify_down(Project* heap[], int i, int size);

void heapify_up(Project* heap[], int i, int n);

Project* extract_max(Project* heap[], int n);

void insert(Project* heap[], Project* x, int n);

#endif

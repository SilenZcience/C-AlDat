#include "project.h"

typedef struct BinHeap {
    Project** heap;
    int size; // Anzahl Elemente im Heap
    int capacity; // Groesse des Arrays
} BinHeap;

void heap_init(BinHeap* h);

void heap_destroy(BinHeap* h);

int heap_insert(BinHeap* h, Project* x);

Project* heap_extract_max(BinHeap* h);

int heap_resize(BinHeap* h, int new_capacity);

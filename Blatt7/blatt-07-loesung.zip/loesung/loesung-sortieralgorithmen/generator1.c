#include <stdio.h>
#include <stdlib.h>

#define CA_ID aingu2angeeNohH1zalei7aehaechoom

int main(int argn, char** argv) {
  if(argn < 2) {
    fprintf(stderr, "Fehler, Parameter <n> erwartet.\n");
    return 1;
  }

  char *end = NULL;
  unsigned long n = strtoul(argv[1], &end, 10);
  printf("%lu\n", n);

  for(unsigned long i=n;i  > 0; --i) {
      printf("%lu\n", i);
  }

  return 0;
}

## Frage 3 (Zum Bearbeiten auf Github oben rechts auf den Bleistift klicken)

Was ist die asymptotische Worst-Case-Laufzeit von Algorithmus C auf einem
Array der Länge n?

- [ ] O(n)
- [x] O(n^2)
- [ ] O(n log n)
- [ ] O(n^3)

### Anleitung
Bitte so ankreuzen:

- [ ] nicht angekreuzt
- [x] angekreuzt.

Bitte ausser dem Kreuz nichts in der Datei verändern!

# ujai2thahVa9Yaira5SieCoo6aiy3ieF

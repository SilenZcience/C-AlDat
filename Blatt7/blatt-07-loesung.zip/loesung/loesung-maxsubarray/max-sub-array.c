#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define CA_ID tah5pieNaephieFaeGh8AhWeexooheip

#define MSA_ALGO_C

int imax(int a, int b) {
    return (a >= b ? a : b);
}

int max_sub_array_a(const int* arr, int n) {
    if(n == 0) return 0;

    int max_sum = arr[0];
    for(int l=0; l < n; ++l) {
        for(int r=l; r < n; ++r) {
            int sum = 0;
            for(int i=l; i <= r; ++i) {
                sum += arr[i];
            }
            if(sum > max_sum) max_sum = sum;
        }
    }
    return max_sum;
}

// vertauscht
int max_sub_array_b(const int* arr, int n) {
    if(n == 0) return 0;

    int max_sum = arr[0];
    for(int l=0; l < n; ++l) {
        int sum = 0;
        for(int r=l; r < n; ++r) {
            sum += arr[r];
            if(sum > max_sum) max_sum = sum;
        }
    }
    return max_sum;
}

int max_sub_array_c(const int* arr, int n) {
    if(n==0) return 0;

    int a=arr[0];
    int b=arr[0];

    for(int k=1; k < n; ++k) {
        b = imax(arr[k], arr[k] + b);
        a = imax(a, b);
    }

    return a;
}

int* read_input(FILE* f, int* n) {
    *n = 0;
    if(fscanf(f, "%d", n) != 1 || n < 0) {
        fprintf(stderr, "[FEHLER] Zeile 1: Natürliche Zahl erwartet.\n");
        return NULL;
    }

    int* arr = malloc(*n*sizeof(int));
    for(int i=0; i < *n; ++i) {
        if(fscanf(f, "%d", &arr[i]) != 1) {
            fprintf(stderr, "[FEHLER] Zeile %d: Zahl erwartet.\n", i+2);
            free(arr);
            return NULL;
        }
    }

    return arr;
}

int main(void) {
    int n;
    int* input = read_input(stdin, &n);

#ifdef MSA_ALGO_A
    printf("Max: %d\n", max_sub_array_a(input, n));
#elifdef MSA_ALGO_B
    printf("Max: %d\n", max_sub_array_b(input, n));
#else
    printf("Max: %d\n", max_sub_array_c(input, n));
#endif

    free(input);

    return 0;
}

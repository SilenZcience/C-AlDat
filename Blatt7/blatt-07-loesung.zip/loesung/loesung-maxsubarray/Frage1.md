## Frage 1 (Zum Bearbeiten auf Github oben rechts auf den Bleistift klicken)

Was ist die asymptotische Worst-Case-Laufzeit von Algorithmus A auf einem
Array der Länge n?

- [ ] O(n)
- [ ] O(n^2)
- [ ] O(n log n)
- [x] O(n^3)

### Anleitung
Bitte so ankreuzen:

- [ ] nicht angekreuzt
- [x] angekreuzt.

Bitte ausser dem Kreuz nichts in der Datei verändern!


# yi7SuebieT3Zeph1pie6thuocau9jewu

## Frage 2 (Zum Bearbeiten auf Github oben rechts auf den Bleistift klicken)

Was ist die asymptotische Worst-Case-Laufzeit von Algorithmus B auf einem
Array der Länge n?

- [x] O(n)
- [ ] O(n^2)
- [ ] O(n log n)
- [ ] O(n^3)

### Anleitung
Bitte so ankreuzen:

- [ ] nicht angekreuzt
- [x] angekreuzt.

Bitte ausser dem Kreuz nichts in der Datei verändern!

# yi7SuebieT3Zeph1pie6thuocau9jewu

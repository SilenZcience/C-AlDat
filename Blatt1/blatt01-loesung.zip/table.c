/* C-Programmierung für Algorithmen und Datenstrukturen
 *
 * Musterlösung Blatt 1, Aufgabe Printf Tabelle
 *
 * Compilieren mit gcc -Wall
 * Aufruf: ./table
 */

#include <stdio.h>

// intern für die Bewertung
#define AD_ID ienie7hoonepi4RaeHooco0ini0to4Vu

int main(void) {
    // Ueberschriften fuer die Tabelle
    printf("%4s %7s %8s\n", "Zahl", "Quadrat", "Kehrwert");

    // Zeile i: i, i^2 und 1/i
    for(int i=1; i <= 12; ++i){
        // %4d: ganze Zahl auf 4 Zeichen aufgefüllt
        // %7d: ganze Zahl auf 7 Zeichen aufgefüllt
        // 8.6f: Fließkommazahl mit 6 Nachkommastellen
        // wichtig hier: 1.0/i, sonst ist 1/i ein Integer und wird auf 0 gerundet
        printf("%4d %7d %8.6f\n", i, i*i, 1.0/i);
    }

    return 0;
}

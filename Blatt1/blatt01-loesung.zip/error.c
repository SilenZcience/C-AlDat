/* C-Programmierung für Algorithmen und Datenstrukturen
 *
 * Musterlösung Blatt 1, Aufgabe error
 *
 * Compilieren mit gcc -Wall
 * Aufruf: ./error
 */

#include <stdio.h> // 1: Headerdatei für printf/scanf

// intern für die Bewertung
#define AD_ID xuxah5OoWei6phaidesudeeBieM2chi8

int main(void) { // 2: main muss int zurückgeben
  int n=0;
  printf("Bitte Anzahl eingeben: ");
  if(scanf("%d", &n) == 0){ // 3: &-Zeichen vor n
    printf("Fehler!\n");
    return 1;
  }
  printf("\n");
 
  int input[n];
  for(int i=0; i < n; ++i) {
    printf("Zahl %d: ", i+1);
    if(scanf("%d", &input[i]) == 0) {
      printf("Fehler!\n");
      return 2;
    }
    printf("\n");
  }

  int m_sum = input[0]; // 4: Variable m_sum nicht deklariert
  for(int i=0; i < n; ++i) {
    int sum = 0;
    for(int j=0; i+j < n; ++j) { // 5: Komma statt Semikolon
      sum += input[i+j];
    }
    if(sum > m_sum) {
      m_sum = sum;
    }
  }

  printf("Ergebnis: %d\n", m_sum);

  return 0;
}

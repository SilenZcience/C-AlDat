/* C-Programmierung für Algorithmen und Datenstrukturen
 *
 * Musterlösung Blatt 1, Aufgabe InsertionSort
 *
 * Compilieren mit gcc -Wall
 * Aufruf: ./insertionsort < eingabe.txt
 */

#include <stdio.h>

// intern für die Bewertung
#define AD_ID zohNg1iseu2ofo8heoceufoomi0uam2N

// Implementierung von InsertionSort, s. AlDat-Skript
void insertion_sort(int A[], int n){
  // Sortiere Element ein, das an Position i steht
  for(int i=1; i < n; ++i) {
    int key = A[i];
    int j = i-1;
    // Suche die Position für i in A[0,...i-1];
    // wenn A[i] vor A[j] stehen muss, schiebe A[j]
    // eine Position nach rechts um Platz für A[i]
    // zu schaffen.
    while(j >= 0 && key < A[j]){
      A[j+1] = A[j];
      --j;
    }
    // A[j+1] ist jetzt die richtige Position für A[i]
    A[j+1] = key;
  }  
}

int main(void) {
  // 1. Schritt: Lies die Anzahl Zahlen n in der Eingabe
  int n;
  if(scanf("%d", &n) != 1){
    printf("Fehler!\n");
    return 1;
  }
 
  // 2. Schritt: Lies die Zahlen der Eingabe; dazu lesen
  // wir genau n Zeilen. Jede Zeile wird als ganz Zahl gelesen.
  int input[n];
  for(int i=0; i < n; ++i) {
    if(scanf("%d", &input[i]) != 1) {
      printf("Fehler!\n");
      return 2;
    }
  }

  insertion_sort(input, n);

  // 3. Schritt: Wir geben die Zahlen wieder aus, getrennt durch ein
  // Leerzeichen.
  for(int i=0; i < n; ++i) {
    printf("%d ", input[i]);
  }
  printf("\n");

  return 0;
}


#include "queue.h"

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#define CA_ID gaeth8iemaevooquoo1iu2haiQu5ahy6

#define RESULT_MSG "Von [%d, %d] nach [%d, %d] gelangt man mit %d Schritten.\n"

// Hinweis: Diese Methode ist sehr hilfreich!
Position move(Position from, Position movement) {
    return (Position) {from.x + movement.x, from.y + movement.y};
}

bool position_equal(Position p, Position q) {
    return (p.x == q.x) && (p.y == q.y);
}

/* Erzeugt ein 2d-int-Array arr[0...width-1][0...height-1] auf dem Heap
 * und initialisiert es mit default_val. */
int** create_array_2d(int width, int height, int default_val) {
    // TODO Implementieren Sie diese Funktion
    int** arr = malloc(sizeof(int*) * width);

    for(int i=0; i < width; ++i) {
        arr[i] = malloc(sizeof(int) * height);
        for(int j=0; j < height; ++j) {
            arr[i][j] = default_val;
        }
    }
    return arr;
}

/* Gegenstück zu create_array_2d; gibt den von arr belegten Speicher wieder frei */
void destroy_array_2d(int** arr, int width) {
    // TODO Implementieren Sie diese Funktion
    for(int i=0; i < width; ++i) {
        free(arr[i]);
        arr[i] = NULL;
    }
}

/* Liefert true zurück, falls Position p nicht betreten werden kann
 * (weil p außerhalb des Spielfeldes liegt oder durch eine Wand blockiert ist */
bool is_blocked(const Labyrinth* l, Position p) {
    // TODO Implementieren Sie diese Funktion
    if(p.x < 0 || p.y < 0) return true;
    if(p.x >= l->width || p.y >= l->height) return true;

    return l->is_wall[p.x][p.y];
}

/* Sucht einen Weg von l->start nach l->target, der möglichst wenige
 * Züge enthält. Gibt die Anzahl Züge auf diesem Weg zurück.
 * Die Funktion erzeugt keine Ausgabe */
int count_steps(const Labyrinth* l) {
    const int n_directions = 4;
    Position moves[] = { {-1, 0}, {1, 0}, {0, -1}, {0, 1} };

    // TODO Implementieren Sie diese Methode. Sie dürfen Datenstrukturen
    //      aus dem Repo benutzen.
    //
    //      Hinweise:
    //      - Passen Sie das Makefile an die gewählte Datnstruktur an :)
    //      - Es werden nur Datenstrukturen aus dem Repo benötigt.
    //      - Die Algorithmen zum Durchsuchen von Graphen aus der Aldat
    //        funktionieren nicht nur auf Graphen!
    DList q;
    dlist_init(&q);

    int** discovered = create_array_2d(l->width, l->height, 0);
    int** dist = create_array_2d(l->width, l->height, -1);

    enqueue(&q, l->start);
    discovered[l->start.x][l->start.y] = true;
    dist[l->start.x][l->start.y] = 0;

    while(!is_empty(&q)) {
        const Position cur_pos = dequeue(&q);

        for(int d=0; d < n_directions; ++d) {
            const Position new_pos = move(cur_pos, moves[d]);
            if(!is_blocked(l, new_pos) && !discovered[new_pos.x][new_pos.y]) {
                discovered[new_pos.x][new_pos.y] = true;
                enqueue(&q, new_pos);
                dist[new_pos.x][new_pos.y] = dist[cur_pos.x][cur_pos.y] + 1;
            }

            if(position_equal(new_pos, l->target)) break;
        }
    }

    const int st_dist = dist[l->target.x][l->target.y];

    dlist_destroy(&q, false);
    destroy_array_2d(discovered, l->width);
    free(discovered);

    destroy_array_2d(dist, l->width);
    free(dist);

    return st_dist;
}

int main(void) {
    /* Hier bitte nichts ändern :) */
    Labyrinth* l = read_labyrinth(stdin);
    if(!l) {
        fprintf(stderr, "Fehler: Konnte Eingabe nicht lesen.\n");
        return 1;
    }
    labyrinth_print(l, stdout);

    printf(RESULT_MSG, l->start.x, l->start.y, l->target.x, l->target.y, count_steps(l));

    labyrinth_destroy(l);
    free(l);

    return 0;
}

#include "unionfind.h"
#include "mergesort.h"
#include "graph.h"

#include <stdio.h>
#include <stdlib.h>

#define CA_ID Thee7thagoto3hieZ2ceo2le9eese2oo

/* (Modifizierter) Algorithmus von Kruskal: Stoppe vorzeitig, wenn der
 * Graph k Zusammenhangskomponenten hat.
 *
 * Eingabe: (unsortiertes) Kantenarray edges (s. Graph.h), Anzahl
 *          Knoten und Kanten im Graphen (letzteres ist die Länge
 *          von edges). Gewünschte Anzahl an Clustern k.
 */
UFNode* kruskal(Edge* edges, int n_nodes, int n_edges, int k) {
    // Sortiere Kanten nach Laenge
    merge_sort_bottom_up(edges, n_edges);

    // Initial ist jeder Knoten allein in seinem Cluster
    UFNode* clusters = malloc(n_nodes * sizeof(UFNode));
    for(int i=0; i < n_nodes; ++i) {
        uf_init(&clusters[i], i);
    }

    int n_clusters = n_nodes;
    for(Edge* e=edges; e != &edges[n_edges]; ++e) {
        UFNode* src_cluster = uf_find(&clusters[e->src]);
        UFNode* tgt_cluster = uf_find(&clusters[e->tgt]);

        if(src_cluster != tgt_cluster) {
            // Wenn die Kante zwei Cluster verbindet, füge sie ein
            uf_union(src_cluster, tgt_cluster);
            --n_clusters;
        }

        // Stoppe vorzeitig, wenn noch k Cluster übrig sind.
        if(n_clusters == k) break;
    }

    return clusters;
}

/* Unter dieser Zeile darf/muss nichts verändert werden :) */
int main(int argn, char** argv) {
    int n_nodes, n_edges, n_clusters;
    Edge* edges = read_edges(stdin, &n_nodes, &n_edges, &n_clusters);
    if(edges == NULL) {
        fprintf(stderr, "Fehler: Konnte Eingabe nicht lesen.\n");
        return 0;
    }

    UFNode* clusters = kruskal(edges, n_nodes, n_edges, n_clusters);
    print_clusters(stdout, clusters, n_nodes, n_clusters);

    free(edges);
    free(clusters);

    return 0;
}


